package com.examplehcl.hclpushtest;

import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPreference {
    SharedPreferences sharedPref;


    public MySharedPreference(Context context) {
        sharedPref = context.getSharedPreferences("sharedpref", Context.MODE_PRIVATE);
    }

    public void storeValue(String s){
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("token", s);
        editor.apply();
    }

    public String getValue(){
        //SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        return  sharedPref.getString("token"," ");
    }
}
