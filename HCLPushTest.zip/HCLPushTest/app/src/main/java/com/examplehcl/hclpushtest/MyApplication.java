package com.examplehcl.hclpushtest;

import android.app.Application;

public class MyApplication extends Application {
    public static MySharedPreference mySharedPreferenceObj;
    @Override
    public void onCreate() {
        super.onCreate();
        mySharedPreferenceObj = new MySharedPreference(this);
    }
}
