package com.examplehcl.hclpushtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtPushtoken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtPushtoken = findViewById(R.id.txtPushToken);
        txtPushtoken.setText(MyApplication.mySharedPreferenceObj.getValue());
    }

}